
const express = require  ('express');
const productController = require ('../controllers/productController');
const { getproductByFirm } = require('../controllers/vendorController');

const router = express.Router();

router.post('/add-product/:firmId',productController.addProduct);
router.get('/:firmId/Products',getproductByFirm);

module.exports = router;
